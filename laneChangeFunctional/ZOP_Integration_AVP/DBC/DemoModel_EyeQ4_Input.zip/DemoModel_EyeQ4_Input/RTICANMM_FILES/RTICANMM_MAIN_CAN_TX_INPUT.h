/*****************************************************************************************************************************/
/* RTICANMM_MAIN_CAN_TX_INPUT */
/*                                                                                                                           */
/*   AUTHOR(S):                                                                                                              */
/*      U. Homann                                                                                                              */
/*      M. Eikermann                                                                                                              */
/*                                                                                                                           */
/*                                                                                                                           */
/*   RTICANMM Date: 19-Feb-2019 19:14:44                                                                                     */
/*   RTICANMM Version: 5.2.737475.8018981481                                                                                     */
/*                                                                                                                           */
/*  Copyright 2020, dSPACE GmbH. All rights reserved.                                                                    */
/*      Brand names or product names are trademarks or registered trademarks of their respective companies or organizations. */
/*                                                                                                                           */
/* ***************************************************************************************************************************/


/* ICM_Lanes_Host_Prot_A_1 */

/* ICM_Lanes_Host_Prot_A_2 */

/* ICM_Lanes_Host_Prot_B_1 */

/* ICM_Lanes_Host_Prot_B_2 */

/* ICM_Lanes_Road_Edge_Prot_A */

/* ICM_Lanes_Road_Edge_Prot_B */

/* ICM_Lanes_Road_Edge_Prot_C */

/* ICM_Lanes_Road_Edge_Prot_Header */

/* ICM_Object_Prot0_A */

/* ICM_Object_Prot0_B */

/* ICM_Object_Prot10_A */

/* ICM_Object_Prot10_B */

/* ICM_Object_Prot11_A */

/* ICM_Object_Prot11_B */

/* ICM_Object_Prot12_A */

/* ICM_Object_Prot12_B */

/* ICM_Object_Prot13_A */

/* ICM_Object_Prot13_B */

/* ICM_Object_Prot14_A */

/* ICM_Object_Prot14_B */

/* ICM_Object_Prot15_A */

/* ICM_Object_Prot15_B */

/* ICM_Object_Prot16_A */

/* ICM_Object_Prot16_B */

/* ICM_Object_Prot17_A */

/* ICM_Object_Prot17_B */

/* ICM_Object_Prot18_A */

/* ICM_Object_Prot18_B */

/* ICM_Object_Prot19_A */

/* ICM_Object_Prot19_B */

/* ICM_Object_Prot1_A */

/* ICM_Object_Prot1_B */

/* ICM_Object_Prot20_A */

/* ICM_Object_Prot20_B */

/* ICM_Object_Prot21_A */

/* ICM_Object_Prot21_B */

/* ICM_Object_Prot22_A */

/* ICM_Object_Prot22_B */

/* ICM_Object_Prot23_A */

/* ICM_Object_Prot23_B */

/* ICM_Object_Prot24_A */

/* ICM_Object_Prot24_B */

/* ICM_Object_Prot25_A */

/* ICM_Object_Prot25_B */

/* ICM_Object_Prot26_A */

/* ICM_Object_Prot26_B */

/* ICM_Object_Prot27_A */

/* ICM_Object_Prot27_B */

/* ICM_Object_Prot28_A */

/* ICM_Object_Prot28_B */

/* ICM_Object_Prot29_A */

/* ICM_Object_Prot29_B */

/* ICM_Object_Prot2_A */

/* ICM_Object_Prot2_B */

/* ICM_Object_Prot30_A */

/* ICM_Object_Prot30_B */

/* ICM_Object_Prot31_A */

/* ICM_Object_Prot31_B */

/* ICM_Object_Prot32_A */

/* ICM_Object_Prot32_B */

/* ICM_Object_Prot33_A */

/* ICM_Object_Prot33_B */

/* ICM_Object_Prot34_A */

/* ICM_Object_Prot34_B */

/* ICM_Object_Prot35_A */

/* ICM_Object_Prot35_B */

/* ICM_Object_Prot36_A */

/* ICM_Object_Prot36_B */

/* ICM_Object_Prot37_A */

/* ICM_Object_Prot37_B */

/* ICM_Object_Prot38_A */

/* ICM_Object_Prot38_B */

/* ICM_Object_Prot39_A */

/* ICM_Object_Prot39_B */

/* ICM_Object_Prot3_A */

/* ICM_Object_Prot3_B */

/* ICM_Object_Prot4_A */

/* ICM_Object_Prot4_B */

/* ICM_Object_Prot5_A */

/* ICM_Object_Prot5_B */

/* ICM_Object_Prot6_A */

/* ICM_Object_Prot6_B */

/* ICM_Object_Prot7_A */

/* ICM_Object_Prot7_B */

/* ICM_Object_Prot8_A */

/* ICM_Object_Prot8_B */

/* ICM_Object_Prot9_A */

/* ICM_Object_Prot9_B */
